<?php

$name = 'Sendinblue Subscription';
$type = 'app';
$guid = 'c42c554e-3a6b-1d84-e1af-5c610a042ae3';
$version = '1.0';
$license = 'MIT';
$description = '';
$author = 'Roy Hadrianoro';
$url = 'https://www.schlix.com';
$email = 'roy.hadrianoro@schlix.com';
$copyright = 'Copyright &copy;2019 Roy Hadrianoro';