<?php

$name = 'Sendinblue Subscription';
$type = 'block';
$guid = 'c42c554e-3a6b-1d84-e1af-5c610a042ae3';
$version = '1.1';
$license = 'MIT';
$description = 'Add Sendinblue subscription form.';
$author = 'Roy H';
$url = 'https://github.com/ryhdr/sendinblue-subscription-schlix';
$email = 'ryhdr@maysora.com';
$copyright = 'Copyright &copy;2020 Roy Hadrianoro';